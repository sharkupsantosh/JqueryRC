x = {
  "data": {
    "emp": [{
        "id": "1",
        "name": "Snatch",
        "type": "Software Developer"
      },
      {
        "id": "2",
        "name": "WitchesofEastwick",
        "type": "UI Developer"
      },
      {
        "id": "3",
        "name": "X-Men",
        "type": "action"
      },
      {
        "id": "4",
        "name": "OrdinaryPeople",
        "type": "drama"
      },
      {
        "id": "5",
        "name": "BillyElliot",
        "type": "drama"
      },
      {
        "id": "6",
        "name": "ToyStory",
        "type": "children"
      }
    ],
    "com": [{
        "sno": "1",
        "cname": "WIPRO",
        "loc": "Banglore"
      },
      {
        "sno": "2",
        "cname": "TCS",
        "loc": "Kolkatta"
      },
      {
        "sno": "3",
        "cname": "DELL",
        "loc": "Chennai"
      },
      {
        "sno": "4",
        "cname": "OFS",
        "loc": "Delhi"
      },
      {
        "sno": "5",
        "cname": "IBM",
        "loc": "Chennai"
      },
      {
        "sno": "6",
        "cname": "Google",
        "loc": "Madurai"
      }
    ]
  }
}
id = [];
name = [];
type = [];
sno = [];
cname = [];
loc = [];

function companyTable() {
  for (var i = 0; i < (x.data.com).length; i++) {
    sno[i] = x.data.com[i].sno;
    cname[i] = x.data.com[i].cname;
    location[i] = x.data.com[i].loc;
  }
  for (var i = 0; i < 6; i++) {
    console.log(x.data.com[i].cname);
    console.log(x.data.com[i].loc);
  }
  for (i = 0; i < (x.data.com).length; i++) {
    var row = document.getElementById("companytable").insertRow();
    for (j = 0; j < 1; j++) {
      row.insertCell().innerHTML = (x.data.com[i].sno);
      row.insertCell().innerHTML = (x.data.com[i].cname);
      row.insertCell().innerHTML = (x.data.com[i].loc);
      row.insertCell().innerHTML = ("<button type='button' class='btn btn-sm btn-success'><span class='glyphicon glyphicon-pencil'></span>Edit</button> <button type='button' class='btn btn-sm btn-danger'><span class='glyphicon glyphicon-trash'></span> Delete</button>");
    }
  }
}

function empTable() {
  for (var i = 0; i < (x.data.emp).length; i++) {
    sno[i] = x.data.emp[i].sno;
    cname[i] = x.data.emp[i].cname;
    location[i] = x.data.emp[i].loc;
  }
  for (var i = 0; i < 6; i++) {
    console.log(x.data.emp[i].name);
    console.log(x.data.emp[i].type);
  }
  for (i = 0; i < (x.data.emp).length; i++) {
    var row = document.getElementById("employeetable").insertRow();
    for (j = 0; j < 1; j++) {
      row.insertCell().innerHTML = (x.data.emp[i].id);
      row.insertCell().innerHTML = (x.data.emp[i].name);
      row.insertCell().innerHTML = (x.data.emp[i].type);
      row.insertCell().innerHTML = ("<button type='button' class='btn btn-sm btn-success'><span class='glyphicon glyphicon-pencil'></span>Edit</button> <button type='button' class='btn btn-sm btn-danger'><span class='glyphicon glyphicon-trash'></span> Delete</button>");
    }
  }
}
